package Lab7;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class ConversationSystem {
	private static ArrayList<Topic> topics;

	public static Topic findTopicByName(String name) {
		for (Topic t : topics)
			if (t.getTitle().equals(name))
				return t;
		System.err.println("Topic named " + name + " not found");
		return null;
	}

	public static void main(String[] args) throws FileNotFoundException {
		topics = readConversation("./Lab7/Sample.txt");
		runConversation();
	}

	public static void runConversation() {
		Scanner userInput = new Scanner(System.in);
		Topic current = findTopicByName("Start");
		while (true) {
			// displays content and options
			boolean changedTopic = false;
			String newTopic = null;
			for (String content : current.getContent()) {
				String result = null;
				if (content.matches(".*<<.*>>.*")) {
					result = handleCommand(content);
				}
				if (result != null) {
					content = result;
				} else {
					continue;
				}
				if (content.contains("[[")) {
					newTopic = Topic.getTopicFromOption(content.substring(2, content.length() - 2)).trim();
					content = Topic.getOutputFromOption(content.substring(2, content.length() - 2)).trim();
					System.out.println(content);
					changedTopic = true;
					break;
				}
				System.out.println(content);
			}

			if (changedTopic) {
				current = findTopicByName(newTopic);
				continue;
			}

			// user options
			if (!current.hasOptions())
				break;
			for (int i = 0; i < current.getNumberOfOptions(); i++) {
				System.out.println(i + ": " + Topic.getOutputFromOption(current.getOption(i)));
			}
			// get user choice
			String input = userInput.nextLine();
			if (input.matches("\\d*")) {
				int choice = Integer.parseInt(input);
			
				// check for valid choice
				if (choice >= 0 && choice < current.getNumberOfOptions()) {
					// gets the next topic
//					System.out.println(current.getOption(choice));
				
					String nextTopicName = Topic.getTopicFromOption(current.getOption(choice));
//					System.out.println(nextTopicName);
					current = findTopicByName(nextTopicName);
				} else {
					System.out.println("Invalid choice");
				}
			} else if (input.matches("<<.+>>")) {
				String result = handleCommand(input);
				if (result != null) {
					System.out.println("[+] Result : " + result);
					if (result.contains("[[")) {
						current = findTopicByName(Topic.getTopicFromOption(result.substring(2, result.length() - 2)).trim());
						result = Topic.getOutputFromOption(result.substring(2, result.length() - 2)).trim();
						System.out.println(result);
						System.out.println(current);
						continue;
					}					
				}
				else
					System.out.println("[+] Result : Error");
			} else {
				System.out.println("Invalid input");
				continue;
			}

		}
	}

	// If this function return "null", command is invalid
	public static String handleCommand(String content) {
		int start = content.indexOf("<<") + 2;
		int end = content.indexOf(">>");
		String command = content.substring(start, end);
		if (command.matches("\\s*set.*")) { // return current value of variable or null
			String math;
			if (command.matches("\\s*set\\s+.+[\\+\\-\\*/%]=.+")) {
				math = command.substring(command.indexOf("=") - 1, command.indexOf("=") + 1);
			} else if (command.matches("\\s*set\\s+.+=.+")) {
				math = "=";
			} else {
				System.out.println("Invalid command");
				return null;
			}
			String name = command.substring(command.indexOf("set") + 3, command.indexOf(math)).trim();
			String value = command.substring(command.indexOf(math) + math.length()).trim();
			Variable v = Variable.getVariable(name);
			if (v == null) {
				if (math.equals("=")) {
					Variable.setVariable(name, value);
					System.out.println("Create a new " + name + " is set to " + value);
					return value;
				} else {
					System.out.println(name + " does not exist");
					return null;
				}
			} else {
				v.calculate(math, value);
				System.out.println(name + " is set to " + v.getValue());
				return v.getValue();
			}
		} else if (command.matches("\\s*get.*")) { // return content replaced {value of variable} or null
			String name = command.substring(command.indexOf("get") + 3).trim();
			Variable v = Variable.getVariable(name);
			if (v != null) {
				String value = Variable.getVariable(name).getValue();
				content = content.replace(command, value).replace("<<", "").replace(">>", "");
				return content;
			} else {
				System.out.println(name + " does not exist. Please set value for " + name);
				return null;
			}
		}

		else if (command.matches("\\s*if.*")) { // return content or null
			if (!content.contains("<<endif>>")) {
				System.out.println("Not found <<endif>>");
				return null;
			}
			if (!command.contains("get")) {
				String varName = command.substring(command.indexOf("if") + 2).trim();
				Variable v = Variable.getVariable(varName);
				if (v != null) {
					String value = v.getValue();
					if (value.equals("1")) {
						String newContent = content.substring(content.indexOf(">>") + 2, content.indexOf("<<endif>>"));
						return newContent;
					} else {
						System.out.println("Condition is false!");
						return null;
					}
				} else {
					System.out.println(varName + " does not exist.");
					return null;
				}
			} else {
				String getCommand = command.substring(command.indexOf("get"));
				getCommand = "<<" + getCommand + ">>";
				String value = handleCommand(getCommand).trim();
				if (value != null) {
					String comparedValue = content
							.substring(content.indexOf("=") + 1, content.indexOf(">>", content.indexOf("="))).trim();
					String newContent = content.substring(content.indexOf(">>", content.indexOf("=")) + 2,
							content.indexOf("<<endif>>"));
//					System.out.println(value + " " + comparedValue);
					if (value.equals(comparedValue)) {
						System.out.println("Condition is true");
						return newContent;
					} else {
						System.out.println("Condition is false!!");
						return null;
					}
				} else {
					System.out.println("Cannot do get command in if because the variable does not exist");
					return null;
				}
			}

		}
		return null;
	}

	public static ArrayList<Topic> readConversation(String fileName) throws FileNotFoundException {
		ArrayList<Topic> topics = new ArrayList<>();
		Scanner scan = new Scanner(new File(fileName));
		Topic current = null;
		while (scan.hasNextLine()) {
			String line = scan.nextLine();
			if (line.length() < 2)// skip blank lines
				continue;
			if (line.startsWith("::")) {
				if (current != null)
					topics.add(current);
				current = new Topic(line.substring(2));
			} else if (line.startsWith("[[")) {
				current.addOption(line.substring(2, line.length() - 2));
			} else {
				current.addContent(line);
			}
		}
		topics.add(current);
		return topics;
	}
}

class Topic {
	private String title;
	private ArrayList<String> content = new ArrayList<>();
	private ArrayList<String> options = new ArrayList<>();
//	private ArrayList<Variable> variables = new ArrayList<>();

	public Topic(String title) {
		this.title = title;
	}

	public String getOption(int i) {
		return options.get(i);
	}

	public int getNumberOfOptions() {
		return options.size();
	}

	public boolean hasOptions() {
		return !options.isEmpty();
	}

	public String[] getContent() {
		String[] arr = new String[content.size()];
		content.toArray(arr);
		return arr;
	}

	public Object getTitle() {
		return title;
	}

	public void addContent(String str) {
		content.add(str);
	}

	public void addOption(String str) {
		options.add(str);
	}

	public String toString() {
		return title;
	}

	public static String getOutputFromOption(String option) {
		if (!option.contains("->")) {
			return option;
		}
		String output = option.substring(0, option.indexOf("->"));
		output = output.trim();
		return output;
	}

	public static String getTopicFromOption(String option) {
		if (!option.contains("->")) {
			return option;
		}
		String topic = option.substring(option.indexOf("->") + 2);
		topic = topic.trim();
		return topic;
	}
}

class Variable {
	private static ArrayList<Variable> variables = new ArrayList<>();
	public String name;
	private String value;
	boolean isInt = false;

	public Variable(String name, String value) {
		this.name = name;
		this.value = value;
		try {
			Integer.parseInt(value);
			this.isInt = true;
		} catch (Exception e) {
		}

//		System.out.println(this.isInt);
	}

	public String getValue() {
		return value;
	}

	public static void setVariable(String name, String value) {
		variables.add(new Variable(name, value));
	}

	public static Variable getVariable(String name) {
		for (Variable v : variables) {
			if (v.name.equals(name)) {
				return v;
			}
		}
		return null;
	}

	public void calculate(String math, String value) {
		if (!isInt) {
			if (math.charAt(0) == '=') {
				this.value = value;
			} else if (math.charAt(0) == '+') {
				this.value += value;
			}
			return;
		}
		try {
			switch (math.charAt(0)) {
			case '+':
				this.value = "" + (Integer.parseInt(this.value) + Integer.parseInt(value));
				break;
			case '-':
				this.value = "" + (Integer.parseInt(this.value) - Integer.parseInt(value));
				break;
			case '*':
				this.value = "" + (Integer.parseInt(this.value) * Integer.parseInt(value));
				break;
			case '/':
				this.value = "" + ((int) (Integer.parseInt(this.value) / Integer.parseInt(value)));
				break;
			case '%':
				this.value = "" + ((int) (Integer.parseInt(this.value) % Integer.parseInt(value)));
				break;
			case '=':
				this.value = "" + (Integer.parseInt(value));
				break;
			}
		} catch (Exception e) {
			System.out.println(this.name + " is int but value is not int");
		}
	}
}
