package ZeldaDownload;

public interface CanBeDrawn {
	void draw();
}
