package ZeldaDownload;

public enum BlockType {
	grass(50, 50), // 0
	wall(50, 50), 
	platform(25, 25);
	int width, height;
	BlockType(int w, int h) {
		width = w;
		height = h;
	}
}
