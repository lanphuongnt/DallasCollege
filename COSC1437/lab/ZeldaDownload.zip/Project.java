package ZeldaDownload;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Scanner;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.JFrame;
import javax.swing.JPanel;

enum Scene {
	Menu, Game, GameOver
}

public class Project {
	public static String mainPath = "ZeldaDownload/";
	public static ArrayList<Actor> actors = new ArrayList<>(); // Includes player and enemies
	public static ArrayList<GameObject> gameObjects = new ArrayList<>();

	public static GamePanel gamePanel;
	private static MenuPanel menuPanel;
	public static GameOverPanel gameOverPanel;
	private static ProjectPanel currentPanel;

	private static JFrame frame;
	private static boolean isDrawing;
	public static Dimension panelSize = new Dimension(1000, 500);

	public static void main(String[] args) {
		while (true) {
			try {
				frame = new JFrame("Game");
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				menuPanel = new MenuPanel(panelSize);
				gamePanel = new GamePanel(panelSize);
				gameOverPanel = new GameOverPanel(panelSize);
				// set the initial scene
				currentPanel = menuPanel;
				frame.add(menuPanel);
		
				frame.pack();
				frame.setVisible(true);
				isDrawing = true;
				clear();
				playMP3(Project.mainPath + "sound/background_music.wav", true);
				
				loop();
			} catch (ConcurrentModificationException ex) {
				System.out.println("Please reload the game!: " + ex);
				frame.dispose();
			}
		}
	}
	// switch the panel

	public static void loop() {
		long currentTime;
		long deltaTime = 0;

		currentTime = System.currentTimeMillis();
		while (true) {
			// act (move) only move actors when we are in a game scene
			if (currentPanel.getScene() == Scene.Game) // if the current panel is the game panel(or its subclasses)
			{
				for (Actor a : actors) {
					a.act(deltaTime);
				}
			}

			if (isDrawing) {
				currentPanel.repaint();
			}

			deltaTime = System.currentTimeMillis() - currentTime;
			try {
				Thread.sleep(Math.max(1, 20 - deltaTime));
			} catch (InterruptedException e) {
			}
			currentTime = System.currentTimeMillis();
		}
	}

	public static void switchScene(Scene newScene) {
		isDrawing = false;
		frame.remove((JPanel) currentPanel); // tell the panel it is closed, typically this is to stop listening for
												// events
		currentPanel.panelClosed();
		switch (newScene) {
		case Game:
//			currentPanel = gamePanel;
			System.out.println("Create new panel");
			gamePanel = new GamePanel(panelSize);
			currentPanel = gamePanel;
			break;
		case Menu:
			currentPanel = menuPanel;
			break;
		case GameOver:
			currentPanel = gameOverPanel;
			break;
		}

		frame.add(currentPanel);
		currentPanel.requestFocus(); // so that events(keys,mouse clicks) can work on the panel
		currentPanel.panelOpened(); // tell the panel it is open (typically restarts their listeners)
		frame.revalidate(); // redo the layout of the panel
		isDrawing = true;
	}

	public static void addActor(Actor a) {
		actors.add(a);
	}

	public static void addGameObject(GameObject go) {
		gameObjects.add(go);
	}
	
	public static void clearNotExistedGameObject() {
		// Clear dead object
		ArrayList<GameObject> GOS = new ArrayList<>(Project.gameObjects);
		for (GameObject go : GOS) {
			if (!go.isExisting()) {
				Project.gameObjects.remove(go);
			}
		}
		ArrayList<Actor> tempActors = new ArrayList<>(Project.actors);
		for (Actor a : tempActors) {
			if (!((GameObject) a).isExisting()) {
				Project.actors.remove(a);
			}
		}
	}
	
	public static void playMP3(String soundFile) {
		playMP3(soundFile, false);
	}
	public static void playMP3(String soundFile, boolean repeat) {
		try {
			File file = new File(soundFile);
			AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(file);
			Clip clip = AudioSystem.getClip();
			clip.open(audioInputStream);
			clip.start();
			if (repeat) {
				clip.loop(Clip.LOOP_CONTINUOUSLY);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void clear() {
		gameObjects = new ArrayList<>();
		actors = new ArrayList<>();
	}
}

interface DrawingPanel {
	void panelClosed();

	void panelOpened();
}

abstract class ProjectPanel extends JPanel implements DrawingPanel {
	abstract Scene getScene();
}

class MenuPanel extends ProjectPanel implements DrawingPanel {
	private int width, height;
	private Rectangle start = new Rectangle(200, 85, 520, 90);
	private Rectangle resume = new Rectangle(200, 205, 520, 90);
	private Rectangle exit = new Rectangle(200, 320, 520, 90);
//	private JButton start  
	private BufferedImage image;
	private MouseAdapter menuMouse = new MouseAdapter() {
		public void mouseReleased(MouseEvent e) {
			if (start.contains(e.getPoint())) {
				Project.switchScene(Scene.Game);
				Project.gamePanel.loadData(false);// create a new game

			}
			if (resume.contains(e.getPoint())) {
				Project.switchScene(Scene.Game);
				Project.gamePanel.loadData(true);
//				Project.gamePanel.state = GameState.RUNNING;
			}
			if (exit.contains(e.getPoint())) {
				System.exit(0);
			}
		}
	};

	public MenuPanel(Dimension panelSize) {
		this.setPreferredSize(panelSize);
		width = (int) panelSize.getWidth();
		height = (int) panelSize.getHeight();
		image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		panelOpened();
	}

	public void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);
		Graphics2D g2 = (Graphics2D) image.getGraphics();
		
		// Draw background
		try {
			BufferedImage bi = ImageIO.read(new File(Project.mainPath + "image/menu.png"));
			
			g2.drawImage(bi, 0, 0, Project.panelSize.width, Project.panelSize.height, null);			
		}
		catch (Exception ex) {
			System.out.println("Error when drawing menu background: " + ex.toString());
		}

		
//		g.setColor(Color.darkGray);
//		System.out.println(this.getWidth());
//		g2.fillRect(0, 0, this.getWidth(), this.getHeight());
//		g.fillRect(0, 0, width, height);
//		g2.setColor(Color.blue);
//		g2.draw(start);
//		g2.draw(resume);
//		g2.draw(exit);
//		g2.setColor(Color.white);
//		g2.setFont(new Font("Arial", Font.PLAIN, 80));
//		g2.drawString("Start", start.x + 10, start.y + 80);
//		g2.drawString("Resume", resume.x + 10, resume.y + 80);
//		g2.drawString("Exit", exit.x + 10, exit.y + 80);
		graphics.drawImage(image, 0, 0, this.getWidth(), this.getHeight(), null);
		g2.dispose();
	}

	public void panelClosed() {
		this.removeMouseListener(menuMouse);
	}

	public void panelOpened() {
		this.addMouseListener(menuMouse);
	}

	Scene getScene() {
		return Scene.Menu;
	}
}

enum GameState {
	RUNNING, PAUSED,
}

class GamePanel extends ProjectPanel implements DrawingPanel {
	GameState state = GameState.RUNNING; // Use to side scrolling
	public static int CameraX = 0, CameraY = 0;

	private JPanel controlBar;
	private Map map;
	private JPanel game;
	private static GamePanel instance;
	private BufferedImage image; // draw everything to this
	private int width, height, NUM_TARGET = 5;
	private boolean keys[] = new boolean[256];

	// this is just a generic player to test evens (moving in the scene)
	private static Character character;

	// chu y
//	Target target = new Target(20, 20);
	ArrayList<Enemy> enemies = new ArrayList<>(); // list enemies
	private KeyListener gameKeyboard = new KeyListener() {
		public void keyTyped(KeyEvent e) {
		}

		public void keyPressed(KeyEvent e) {
			if (e.getKeyCode() < 256)
				keys[e.getKeyCode()] = true;
			if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
				Project.switchScene(Scene.Menu);
				System.out.println("Switch to Menu");
			}
			if (e.getKeyCode() == KeyEvent.VK_P) {
				state = GameState.PAUSED;
			}
			if (e.getKeyCode() == KeyEvent.VK_R) {
				state = GameState.PAUSED;
				try {
					writeInfo();
				} catch (Exception ex) {
					System.out.println("Can't write the GameObjects: " + e.toString());
				}
				Project.switchScene(Scene.Menu);
			}
		}

		public void keyReleased(KeyEvent e) {
			if (e.getKeyCode() < 256)
				keys[e.getKeyCode()] = false;
		}
	};

	public GamePanel(Dimension panelSize) {
		this.setPreferredSize(panelSize);
//		character = new Character(65, 50, Project.mainPath + "image/swordsman.png");
		width = (int) panelSize.getWidth();
		height = (int) panelSize.getHeight();
		image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		instance = this;
		CameraX = 0;
		CameraY = 0;
		this.map = new Map();
	}

	public void moveCamera() {
		int current = (int) character.location.getX();
		if (current < 0 || current > getWidth() * 1 / 5) {
			if (current - CameraX > getWidth() * 4 / 5)
				CameraX = current - (getWidth() * 4 / 5);
			else if (current - CameraX < getWidth() * 1 / 5)
				CameraX = current - (getWidth() * 1 / 5);
		}

		current = (int) character.location.getY();
		if (current < 0 || current > getHeight() * 1 / 3) {
			if (current - CameraY > getHeight() * 2 / 3)
				CameraY = current - (getHeight() * 2 / 3);
			else if (current - CameraY < getHeight() * 1 / 3)
				CameraY = current - (getHeight() * 1 / 3);
		}
	}

	public void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);
//		while (true) {
		Graphics2D g = (Graphics2D) image.getGraphics();

		// draw background
		
		
		g.setColor(Color.white);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		if (state == GameState.RUNNING) {
			map.draw(g);
//				if (!character.isDead())
			character.draw(g);
			if (countAliveTargets() > 0) {
				ArrayList<GameObject> GOS = new ArrayList<>(Project.gameObjects);
				for (GameObject go : GOS) {
					if (go instanceof Target) {
						if (((Target) go).isExisting())
							go.draw(g);
						else
							Project.gameObjects.remove(go);

					}
				}
			} else if (countAliveTargets() == 0) {
				Target.generateTargets(NUM_TARGET);
			}

			for (Enemy e : enemies) {
				e.draw(g);
			}
//			// chu y
//			if (target.isAlive)
//				target.draw(g);
			for (FireBall f : character.fireballs)
				f.draw(g);
			moveCamera();
		}
		graphics.drawImage(image, 0, 0, this.getWidth(), this.getHeight(), null);
		g.dispose();
	}



	public int countAliveTargets() {
		int count = 0;
		for (GameObject go : Project.gameObjects) {
			if (go instanceof Target) {
				if (((Target) go).isExisting())
					count++;
			}
		}
		return count;
	}

	public void panelClosed() {
		this.removeKeyListener(gameKeyboard);
		try {
			Project.clear();
		}
		catch (ConcurrentModificationException ex) {
			System.out.println("Project clear");
		}
		finally {
			
		}
	}

	public void panelOpened() {
		this.addKeyListener(gameKeyboard);
	}

	public static boolean getKey(int key) {
		return instance.keys[key];
	}

	Scene getScene() {
		return Scene.Game;
	}

	public void controlDraw() {
		controlBar.addMouseListener(new MouseAdapter() {
			public void mouseReleased(MouseEvent e) {

			}
		});
	}

	public void readLevel() {
		try {
			Scanner file = new Scanner(new File(Project.mainPath + "data/mapdata.txt"));
			while (file.hasNextLine()) {
				String line = file.nextLine().trim();
				if (line.startsWith("Block")) {
					String tokens[] = line.split(",");
					Map.blocks.add(new Block(Integer.parseInt(tokens[1]), Integer.parseInt(tokens[2]),
							Integer.parseInt(tokens[3]), Integer.parseInt(tokens[4])));
				}
				// read Enemy
				if (line.startsWith("NormalEnemy")) {
					String tokens[] = line.split(",");
					enemies.add(new NormalEnemy(Integer.parseInt(tokens[1]), Integer.parseInt(tokens[2]),
							Integer.parseInt(tokens[3]), Integer.parseInt(tokens[4]), tokens[5]));
					System.out.println("Added enemy " + Project.gameObjects.size() + " " + Project.actors.size());
				} else if (line.startsWith("Boss")) {
					String tokens[] = line.split(",");
					enemies.add(new Boss(Integer.parseInt(tokens[1]), Integer.parseInt(tokens[2]),
							Integer.parseInt(tokens[3]), Integer.parseInt(tokens[4]), tokens[5]));
				}
				if (line.startsWith("Character")) {
					String tokens[] = line.split(",");
					this.character = new Character(Integer.parseInt(tokens[1]), Integer.parseInt(tokens[2]), Project.mainPath + "image/swordsman.png");
					System.out.println("Read Character");
				}
			}

		} catch (FileNotFoundException e) {
		}
	}

	public static Point2D getCharacterLocation() {
		return new Point2D.Double(character.location.getX(), character.location.getY());
	}

	/**
	 * Serialization GameObjects are serializable
	 */

	public void writeInfo() throws IOException {
		FileOutputStream outStream = new FileOutputStream("GameObjects.dat");
		ObjectOutputStream objectOutputFile = new ObjectOutputStream(outStream);
		
		for (GameObject go : Project.gameObjects) {
			objectOutputFile.writeObject(go);
		}
		objectOutputFile.close();
		
		System.out.println("Write successfully");
	}

	public void readInfo() throws IOException, ClassNotFoundException {
		System.out.println("Open file GameObjects.dat");
		FileInputStream inStream = new FileInputStream("GameObjects.dat");
		ObjectInputStream objectInputFile = new ObjectInputStream(inStream);
		Project.gameObjects.clear();
		try {
	        while (true) {
	            Project.gameObjects.add((GameObject) objectInputFile.readObject());
	        }
	    } catch (EOFException e) {
	        // Đã đọc hết file
	        System.out.println("End of file reached.");
	    } finally {
	        objectInputFile.close();
	        inStream.close();
	    }
		System.out.println("Read successfully");
	}

	public void loadData(boolean isNotNewGame) {
		if (isNotNewGame == false) {
			System.out.println("New Game: " + Project.gameObjects.size() + " " + Project.actors.size());
			readLevel();
			if (this.character == null) {
				this.character = new Character(65, 50, Project.mainPath + "image/swordsman.png");
			}
			this.map = Map.map;
		} else {
			try {
				System.out.println("Load Game");
				readInfo();
				for (GameObject go : Project.gameObjects) {
					if (go instanceof Character) {
						System.out.print("Read Character: ");
						this.character = (Character) go;
						this.character.setupData();
						System.out.println("OK");
					}
					else if (go instanceof Enemy) {
						System.out.print("Read Enemy: ");
						Enemy ene = (Enemy) go;
						ene.setupData();
						this.enemies.add(ene);
						System.out.println("OK");
					}
					else if (go instanceof Block) {
						System.out.print("Read Block: ");
						this.map.blocks.add((Block) go);
						System.out.println("OK");
					}
					else if (go instanceof Target) {
						System.out.println("Here is target");
						go.setupData();
					}
				}
				
				
			} catch (Exception e) {
				System.out.println("Error when loading data: " + e);
			}

		}
	}
}

class GameOverPanel extends ProjectPanel implements DrawingPanel{
	int width, height;
	private Rectangle home = new Rectangle(90, 340, 350, 100);
	private Rectangle retry = new Rectangle(480, 340, 350, 100);
//	private JButton start  
	private BufferedImage image;
	private MouseAdapter gameOverMouse = new MouseAdapter() {
		public void mouseReleased(MouseEvent e) {
			if (home.contains(e.getPoint())) {
				Project.switchScene(Scene.Menu);
			}
			if (retry.contains(e.getPoint())) {
				Project.switchScene(Scene.Game);
				Project.gamePanel.loadData(false);
			}
		}
	};
	
	public GameOverPanel(Dimension panelSize) {
		this.setPreferredSize(panelSize);
		width = (int) panelSize.getWidth();
		height = (int) panelSize.getHeight();
		image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		panelOpened();
	}
	
	@Override
	public void panelClosed() {
		this.removeMouseListener(gameOverMouse);
	}

	@Override
	public void panelOpened() {
		this.addMouseListener(gameOverMouse);
	}

	@Override
	Scene getScene() {
		return Scene.GameOver;
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2 = (Graphics2D) image.getGraphics();
		
		// Draw background
		try {
			BufferedImage bi = ImageIO.read(new File(Project.mainPath + "image/gameover.png"));
			
			g2.drawImage(bi, 0, 0, Project.panelSize.width, Project.panelSize.height, null);			
		}
		catch (Exception ex) {
			System.out.println("Error when drawing gameover image: " + ex.toString());
		}

		
//		g.setColor(Color.darkGray);
//		System.out.println(this.getWidth());
//		g2.fillRect(0, 0, this.getWidth(), this.getHeight());
//		g.fillRect(0, 0, width, height);
		g2.setColor(Color.blue);
		g2.draw(home);
		g2.draw(retry);
		g2.setColor(Color.white);
		g2.setFont(new Font("Arial", Font.PLAIN, 80));
//		g2.drawString("home", home.x + 10, home.y + 80);
//		g2.drawString("retry", retry.x + 10, retry.y + 80);
		g.drawImage(image, 0, 0, this.getWidth(), this.getHeight(), null);
		g2.dispose();
	}
}
