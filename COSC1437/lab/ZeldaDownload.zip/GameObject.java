package ZeldaDownload;

import java.awt.BasicStroke;
import java.awt.Graphics;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.io.Serializable;
import java.awt.geom.Area;
import java.awt.geom.Line2D;
import java.util.List;

abstract class GameObject implements Serializable {
	Point2D location;
	Point2D size;

	public GameObject(Point2D loc, Point2D size) {
		this.location = loc;
		this.size = size;
	}

	public abstract boolean isExisting();
	public abstract void draw(Graphics g);

	public abstract Shape getCollision();


	// returns the first game Object hit on the path from start to end or null if
	// the path is clear
	public static GameObject trace(Point2D start, Point2D end, List<GameObject> ignoreCollision) {
		// this is the path I want to go
		Line2D path = new Line2D.Float(start, end);

		// the shape of the path I am going (right now it is 1, we can widen it to fit
		// the size of the character)
		Shape line = new BasicStroke(5f).createStrokedShape(path);

		// and finally we turn the line shape into an area to check intersection
		Area lineArea = new Area(line);

		for (GameObject go : Project.gameObjects) {
//			System.out.println("Trace GameObject");
			if (go == null || ignoreCollision.contains(go) || go instanceof Actor)
				continue;
			// what I could potentially run into
			Area shapeArea = new Area(go.getCollision());
			shapeArea.intersect(lineArea);
			if (!shapeArea.isEmpty())
				return go;
		}
		
		return null;
	}
	
	public void setupData() {
		return;
	}

}
