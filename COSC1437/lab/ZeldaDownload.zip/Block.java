package ZeldaDownload;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;


public class Block extends GameObject { // extends GameObject
//	private BlockType type;
//	private Point location;
//	public Block(Point2D location, BlockType type) {
//		super(location, new Point2D.Float(type.width, type.height));
////		this.type = type;
//		Project.addGameObject(this);
//	}
	
	public Block(int x, int y, int sizeX, int sizeY) {
		super(new Point2D.Float(x, y), new Point2D.Float(sizeX, sizeY));
//		super(new Point2D.Float(x, y), new Point2D.Float(60, 60));
		Project.addGameObject(this);
		System.out.println("Block add to gameob "  + Project.gameObjects.size() + " " + Project.actors.size());
	}
//	public int getX() {
//		return location.x;
//	}
//	public int getY() {
//		return location.y;
//	}
//	public String toString() {
//		return "{" + location.x + ", " + location.y + "}";
//	}
	public void draw(Graphics graphics) {
//		Graphics2D g2 = (Graphics2D) graphics;
		try {
			BufferedImage bi = ImageIO.read(new File(Project.mainPath + "image/block.png"));
			graphics.drawImage(bi, (int) location.getX() -GamePanel.CameraX, (int)location.getY() - GamePanel.CameraY, (int)size.getX(), (int)size.getY(), null);
			graphics.drawRect((int)location.getX() -GamePanel.CameraX,(int)location.getY() -GamePanel.CameraY,(int)size.getX(), (int)size.getY());
		} catch (Exception e) {
			
		}
	}
	
//	@Override
	public Shape getCollision() {
//		System.out.println("Block get Collision");
		return new Rectangle((int)location.getX(),(int)location.getY(),(int)size.getX(), (int)size.getY());
	}
	public boolean isExisting() {
		return true;
	}
}



