package ZeldaDownload;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Shape;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.util.ArrayList;

public class FireBall extends GameObject {

    Point2D velocity;
    public int dame = 20;
    public FireBall(Point2D loc, Point2D velo) {
        super(loc, new Point2D.Float(16,16));
        this.velocity = velo; 
        //Project.addFireBall(this);
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(Color.RED);
        int diameter = (int) size.getX(); // Assuming size is width
        g.fillOval((int) location.getX()-GamePanel.CameraX, (int) location.getY()-GamePanel.CameraY, diameter, diameter);
    }

    @Override
    public Shape getCollision() {
        int diameter = (int) size.getX();
        return new Ellipse2D.Double(location.getX(), location.getY(), diameter, diameter);
    }

    public void act() {
        double newX = location.getX() + velocity.getX();
        double newY = location.getY() + velocity.getY();
        this.location.setLocation(newX, newY);

    }
    public boolean checkCollision(ArrayList<GameObject> gameObjects, ArrayList<Actor> actors) {
		for (GameObject go : gameObjects) {
			if (go instanceof Character) {
				continue;
			}
			if (checkCollision(go)) {
				if (go instanceof Target)
					((Target) go).hit();
				else if (go instanceof Enemy) {
					((Enemy) go).takeDamage(dame);
				}
				return true;
			}		
		}
		for (Actor a : actors) {
			if (a instanceof Enemy)
				if (checkCollision(a)) {
					((Enemy) a).takeDamage(dame);
					return true;
				}
		}
		return false;
	}

	
    public boolean checkCollision(Actor a) {
		Shape mine = this.getCollision();
		Shape other = ((GameObject)a).getCollision();
		Area myArea = new Area(mine);
		Area otherArea = new Area(other);
		myArea.intersect(otherArea);
		
		return !myArea.isEmpty();
	}
	public boolean checkCollision(GameObject go) {
		Shape mine = this.getCollision();
		Shape other = go.getCollision();
		Area myArea = new Area(mine);
		Area otherArea = new Area(other);
		myArea.intersect(otherArea);
		
		return !myArea.isEmpty();
	}
	public boolean isExisting() {
		return true;
	}
}