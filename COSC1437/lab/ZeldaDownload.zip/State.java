package ZeldaDownload;

public enum State{
    WALKING, IDLE, ATTACKING,
}

