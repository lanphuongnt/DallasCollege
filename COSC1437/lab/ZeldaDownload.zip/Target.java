package ZeldaDownload;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

class Target extends GameObject
{
	public static int SIZE = 50;
	transient BufferedImage image;
	boolean isAlive;
	public Target(int x, int y)
	{
		super(new Point2D.Float(x, y), new Point2D.Float(Target.SIZE,Target.SIZE));
		try
		{
			image = ImageIO.read(new File(Project.mainPath + "image/target.png"));
		} catch (IOException e)	{}
		isAlive = true;
		Project.addGameObject(this);
	}
	@Override
	public void setupData() {
		try
		{
			image = ImageIO.read(new File(Project.mainPath + "image/target.png"));
		} catch (IOException e)	{}
	}
	public void draw(Graphics g)
	{
		g.drawImage(image, (int) location.getX() -GamePanel.CameraX, (int) location.getY() -GamePanel.CameraY,(int) size.getX(), (int) size.getY(), null);
	}
	@Override
	public Shape getCollision()
	{
		return new java.awt.geom.Ellipse2D.Float((int) location.getX() ,(int) location.getY(),64,64);
	}
//	@Override
	public void hit()
	{
		isAlive = false;		
	}
//	@Override
	public boolean isExisting()
	{
		return isAlive;
	}
	public static void generateTargets(int num) {
		
		for (int i = 0; i < num; i++) {
			int x, y;
			do {
				x = (int) (Math.random() * 1000);
				y = (int) (Math.random() * 500);				
			}
			while (Map.isBlockPosition(new Rectangle(x, y, Target.SIZE, Target.SIZE)));
			new Target(x, y);
		}
	}
}

