package ZeldaDownload;


import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;

import javax.imageio.ImageIO;



public class Map{
	public static ArrayList<Block> blocks = new ArrayList<>();
	public static Map map = new Map();

//	public Map(String filename, Dimension size) throws FileNotFoundException, InterruptedException {
//		this.setPreferredSize(size);
//		Scanner s = new Scanner(new File(filename));
//		int y = 0;
//		while (s.hasNextLine()) {
//			String line = s.nextLine();
//			for (int x = 0; x < line.length(); x++) {
//				if (line.charAt(x) == '1') {
////					System.out.println(row + " " + col);
//					blocks.add(new Block(new Point2D.Float(x * BlockType.wall.width, y * BlockType.wall.height), BlockType.wall));
////					Thread.sleep(10);
//				}
//			}
//			y++;
//		}
//	}
	
	public void draw(Graphics graphics) {
		drawBackground(graphics);
		
		// draw blocks
		for (Block b : this.blocks) {
			b.draw((Graphics2D)graphics);
		}
	}
	
	public void drawBackground(Graphics graphics) {
		try {
			graphics.setColor(new Color(20, 24, 43));
			BufferedImage bi = ImageIO.read(new File(Project.mainPath + "image/background.png"));
			graphics.drawImage(bi, 0, (0),  (int)(Project.panelSize.getWidth()), (int)( Project.panelSize.getHeight()), null);
//			graphics.fillRect(0, (0),  (int)(Project.panelSize.getWidth()), (int)( Project.panelSize.getHeight()));
//			graphics.setColor(Color.blue);
//			for (int x = 0; x < this.getWidth(); x+= BlockType.grass.width) {
//				for (int y = 0; y < this.getHeight(); y += BlockType.grass.height) {
//					graphics.drawImage(bi, x - GamePanel.CameraX, y - GamePanel.CameraY, BlockType.grass.width, BlockType.grass.height, null);
//				}
//			}

		} catch (Exception e) {

		}
	}

	public static boolean isBlockPosition(Rectangle shape) {
		for (Block b : blocks) {
			if (b.getCollision().intersects(shape)) {
				return true;
			}
		}
		return false;
	}

}


