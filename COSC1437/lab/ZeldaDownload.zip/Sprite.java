package ZeldaDownload;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javax.imageio.ImageIO;

class Sprite
{
	//Inner class to hold animationData
	public static class AnimationData //this really is just a weak version of a static map (fundamentals 3 shows us the right way to do this)
	{
		private static final ArrayList<AnimationData> frameDex = new ArrayList<>();
		public static int getFrameNumber(int i)
		{
			for (AnimationData a : frameDex)
				if (a.animation == i)
					return a.numberOfFrames;
			return 0;
		}
		public static int getSize(int i)
		{
			for (AnimationData a : frameDex)
				if (a.animation == i)
					return a.tileSize;
			return 0;
		}
		public static int getOffsetY(int i)
		{
			for (AnimationData a : frameDex)
				if (a.animation == i)
					return a.offSetY;
			return 0;
		};
		public static void put(int a, int n, int s, int o)
		{			
			new AnimationData(a,n,s,o);
		}		
		private final int animation, numberOfFrames, tileSize, offSetY;
		public AnimationData(int a, int n, int size) 
		{ 		
			this(a,n,size,0);
		}
		public AnimationData(int a, int n, int size, int offsety) 
		{ 		
			animation = a; 
			numberOfFrames = n;
			tileSize = size;
			offSetY = offsety;
			frameDex.add(this);
		}
	}
	public BufferedImage spriteSheet;
	public BufferedImage currentFrame;
	public int animationNumber;
	public int frameNumber = 0;
	public Sprite(String fileName)
	{	
		animationNumber = 9; //starting animation
		loadAnimationData(Project.mainPath + "data/animationData.txt");
		
		//other animation numbers data is omitted
		
		int tileSize = AnimationData.getSize(animationNumber);
		try {
			spriteSheet = ImageIO.read(new File(fileName));
		} catch (IOException e) {
			e.printStackTrace();
		}	
		//init currentFrame
		currentFrame = spriteSheet.getSubimage(0,0, tileSize, tileSize);
	}
	private void loadAnimationData(String fileName) {
        try (Scanner scanner = new Scanner(new File(fileName))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                line = line.trim(); // Loại bỏ khoảng trắng đầu và cuối dòng
                if (line.startsWith("#") || line.isEmpty()) {
                    continue; // Bỏ qua dòng chú thích và dòng trống
                }

                String[] parts = line.split(",");
                if (parts.length >= 4) {
                    try {
                        int animationId = Integer.parseInt(parts[0].trim());
                        int numberOfFrames = Integer.parseInt(parts[1].trim());
                        int tileSize = Integer.parseInt(parts[2].trim());
                        int offsetY = Integer.parseInt(parts[3].trim());
                        System.out.println(animationId+" "+numberOfFrames+" "+tileSize+" "+offsetY);
                        AnimationData.put(animationId, numberOfFrames, tileSize, offsetY);
                    } catch (NumberFormatException e) {
                        System.err.println("error: " + line);
                    }
                } else {
                    System.err.println("error: " + line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void Update() {
        frameNumber = (frameNumber + 1) % AnimationData.getFrameNumber(animationNumber);
        int tileSize = AnimationData.getSize(animationNumber);
        int offsetY = AnimationData.getOffsetY(animationNumber);
        
        int oversizedOffset;
        if (offsetY != 0)
        {
            oversizedOffset = (animationNumber - 21) * tileSize;
            
        }
        else 
        	oversizedOffset = animationNumber*tileSize;
        	
        currentFrame = spriteSheet.getSubimage(
                frameNumber * tileSize,
                offsetY + oversizedOffset,
                
                tileSize,
                tileSize);
    }

//	public void Update()
//	//Note the 20 and 21 hard coding can be avoided by putting what the tilesize is in the animationData
//	{
//		frameNumber = (frameNumber + 1) % AnimationData.getFrameNumber(animationNumber);
//		int tileSize = AnimationData.getSize(animationNumber);
//		if (animationNumber <= 20) //20 is the death animation
//			currentFrame = spriteSheet.getSubimage(frameNumber*tileSize, animationNumber*tileSize, tileSize, tileSize);
//		
//		//oversized tiles
//		if (animationNumber >= 21)
//		{
//			int offsetY = 64 * 21; //this is hardcoded where the oversized animations start (in an practical situation I would have the oversized animations be their own sheet - alternatively, every animation could store its Y location but that is a lot of repeated information to put in your textfile)
//			currentFrame = spriteSheet.getSubimage(frameNumber*tileSize, (animationNumber-21)*tileSize+offsetY, tileSize, tileSize);
//	
//		}
//	}
	public int getNumberOfAnimationFrames()
	{
		return AnimationData.getFrameNumber(animationNumber);		
	}
}