package ZeldaDownload;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.KeyEvent;
import java.awt.geom.Area;
import java.awt.geom.Point2D;
import java.util.ArrayList;


enum Direction {
	UP, DOWN, LEFT, RIGHT,
}

public class Character extends GameObject implements Actor {
	transient public Sprite sprite;
	public static final float MOVE_SPEED = 3f;
	private int health, currentHealth, mana, dame = 50;

	boolean HAND, SWORD;
	transient public ArrayList<FireBall> fireballs = new ArrayList<>();
	Point2D velocity;
	public Direction direction;
	transient private long lastAttackTime = 0;
	private static final long ATTACK_COOLDOWN = 1000; // 1 second cooldown

	public Character(int x, int y, String fileName) {
		super(new Point2D.Float(x, y), new Point2D.Float(60, 60));
		sprite = new Sprite(fileName);
		velocity = new Point2D.Float(0, 0);
		// velocity.setLocation(velocity.getX() - MOVE_SPEED, velocity.getY());
		health = 100;
		mana = 100;
		currentHealth = health;
		SWORD = true;
		HAND = false;
		direction = Direction.LEFT;
		Project.addActor(this);
		Project.addGameObject(this);
		System.out.println("Character add to actor and gameob " + Project.gameObjects.size() + " " + Project.actors.size());
	}

	// shows 1 frame
	long lastUpdate = 0;
	long animationTime = 0;

	@Override
	public void act(float time) {
		boolean update = false;
		if (!isExisting()) {
			System.out.println("Current Health: " + currentHealth);
			sprite.animationNumber = 20;
			update = true;
			animationTime = sprite.getNumberOfAnimationFrames();

			if (System.currentTimeMillis() - lastUpdate > 100) {
				lastUpdate = System.currentTimeMillis();

				if (update || animationTime > 0) {
					sprite.Update();
					animationTime--;
				} else // makes them go to the standing position if you stop moving
				{
//					STOP = false; // release movement (previous animation is done)
					sprite.frameNumber = -1;
					sprite.Update();

				}
			}
			else {
				System.out.println("Game Over: " + Project.gameObjects.size() + " " + Project.actors.size());
				Project.switchScene(Scene.GameOver);
			}
			
			return;
		}
		if (mana < 100)
			mana++;

		if (GamePanel.getKey(KeyEvent.VK_1)) {
			HAND = false;
			SWORD = true;
		}
		if (GamePanel.getKey(KeyEvent.VK_2)) {
			HAND = true;
			SWORD = false;
		}

		if (GamePanel.getKey(KeyEvent.VK_W) || GamePanel.getKey(KeyEvent.VK_UP) && !GamePanel.getKey(KeyEvent.VK_SPACE))
		// if (UP && !STOP)
		{
			// Y-=MOVE_SPEED;
//			location.setLocation(location.getX(), location.getY() - MOVE_SPEED);
			velocity.setLocation(velocity.getX(), velocity.getY() - MOVE_SPEED);
			direction = Direction.UP;
			sprite.animationNumber = 8;
			update = true;
		}
		if (GamePanel.getKey(KeyEvent.VK_S)
				|| GamePanel.getKey(KeyEvent.VK_DOWN) && !GamePanel.getKey(KeyEvent.VK_SPACE))
		// if (DOWN && !STOP)
		{

			// Y+=MOVE_SPEED;
//			location.setLocation(location.getX(), location.getY() + MOVE_SPEED);
			velocity.setLocation(velocity.getX(), velocity.getY() + MOVE_SPEED);
			direction = Direction.DOWN;
			sprite.animationNumber = 10;
			update = true;
		}
		if (GamePanel.getKey(KeyEvent.VK_D)
				|| GamePanel.getKey(KeyEvent.VK_RIGHT) && !GamePanel.getKey(KeyEvent.VK_SPACE))
		// if (RIGHT && !STOP)
		{
			// X+=MOVE_SPEED;
			// location.setLocation(location.getX() + MOVE_SPEED, location.getY());
			velocity.setLocation(velocity.getX() + MOVE_SPEED, velocity.getY());
			direction = Direction.RIGHT;
			sprite.animationNumber = 11;
			update = true;
		}
		if (GamePanel.getKey(KeyEvent.VK_A)
				|| GamePanel.getKey(KeyEvent.VK_LEFT) && !GamePanel.getKey(KeyEvent.VK_SPACE))
		// if (LEFT && !STOP)
		{
			// X-=MOVE_SPEED;
			// location.setLocation(location.getX() - MOVE_SPEED, location.getY());
			velocity.setLocation(velocity.getX() - MOVE_SPEED, velocity.getY());
			direction = Direction.LEFT;
			sprite.animationNumber = 9;
			update = true;
		}
		// check collision
		checkCollision(Project.gameObjects);
		ArrayList<FireBall> fbs = new ArrayList<>(fireballs);
		for (FireBall f : fbs) {
			f.act();
			if (f.checkCollision(Project.gameObjects, Project.actors))
				fireballs.remove(f);
		}
		location.setLocation(location.getX() + velocity.getX(), location.getY() + velocity.getY());

		// friction
		velocity.setLocation(velocity.getX() * .5f, velocity.getY() * .5f);

		if (GamePanel.getKey(KeyEvent.VK_SPACE)) {

			switch (direction) {
			case UP:
				if (SWORD)
					sprite.animationNumber = 21;
				if (HAND && mana > 30) {
					sprite.animationNumber = 4;
					fireballs.add(new FireBall(
							new Point2D.Float((int) (location.getX() - size.getX() / 8), (int) location.getY()),
							new Point2D.Float(0, -5)));
					// fireball.act();
					mana -= 30;
					Project.playMP3(Project.mainPath + "sound/soundshoot.wav");

				}
				break;
			case LEFT:
				if (SWORD)
					sprite.animationNumber = 22;
				if (HAND && mana > 30) {
					sprite.animationNumber = 5;
					fireballs.add(new FireBall(
							new Point2D.Float((int) location.getX(), (int) (location.getY() + size.getY() / 8)),
							new Point2D.Float(-5, 0)));
					// fireball.act();
					mana -= 30;
					Project.playMP3(Project.mainPath + "sound/soundshoot.wav");

				}
				break;
			case DOWN:
				if (SWORD)
					sprite.animationNumber = 23;
				if (HAND && mana > 30) {
					sprite.animationNumber = 6;
					fireballs.add(new FireBall(
							new Point2D.Float((int) (location.getX() - size.getX() / 8), (int) location.getY()),
							new Point2D.Float(0, 5)));
					// fireball.act();
					mana -= 30;
					Project.playMP3(Project.mainPath + "sound/soundshoot.wav");

				}
				break;
			case RIGHT:
				if (SWORD)
					sprite.animationNumber = 24;
				if (HAND && mana > 30) {
					sprite.animationNumber = 7;
					fireballs.add(new FireBall(
							new Point2D.Float((int) location.getX(), (int) (location.getY() + size.getY() / 8)),
							new Point2D.Float(5, 0)));
					// fireball.act();
					mana -= 30;
					Project.playMP3(Project.mainPath + "sound/soundshoot.wav");

				}
				break;
			}

			animationTime = sprite.getNumberOfAnimationFrames();
			update = true;
		}


		// do whatever action is associated with this animation
		if (animationTime == sprite.getNumberOfAnimationFrames() / 2) // halfway through the animation do whatever
																		// action
			CheckSword(); // this should call a method (or switch statement) to figure out what action we
							// are doing based on the animation but since there is only 1 action we can call
							// the method directly

		if (System.currentTimeMillis() - lastUpdate > 100) {
			lastUpdate = System.currentTimeMillis();

			if (update || animationTime > 0) {
				sprite.Update();
				animationTime--;
			} else // makes them go to the standing position if you stop moving
			{
//				STOP = false; // release movement (previous animation is done)
				sprite.frameNumber = -1;
				sprite.Update();

			}
		}
	}

	java.awt.Rectangle swordDebug;

	@Override
	public Shape getCollision() {
		return new Rectangle.Float((int) location.getX() - 15, (int) location.getY(), 30, 30);
	}

	public int getX() {
		return (int) location.getX();
	}
	
	public void checkCollision(ArrayList<GameObject> gameObjects) {
		for (GameObject go : gameObjects) {
			Block b;
			if (go instanceof Block) {
				b = (Block) go;
			} else
				continue;
			if (checkCollision(go)) {
//				b.color = Color.red;
				handleCollision(go);
			}
//			else
//				b.color = Color.green;			
		}
	}

	public boolean checkCollision(GameObject go) {
		Shape mine = this.getCollision();
		Shape other = go.getCollision();
		Area myArea = new Area(mine);
		Area otherArea = new Area(other);
		myArea.intersect(otherArea);

		return !myArea.isEmpty();
//		return mine.intersects(other);
	}

	public void handleCollision(GameObject go) {
		// if things are more or less tile based
		// check location x's and y's

		// other solution is to check individual pixels (points)
		Shape shape = go.getCollision();
		// in which direction am I colliding

//		System.out.println("Size:" + size.getX());
		Point2D right = new Point2D.Double(location.getX() + size.getX() / 4, location.getY() + size.getY() / 4);
		Point2D left = new Point2D.Double(location.getX() - size.getX() / 4, location.getY() + size.getY() / 4);
		Point2D top = new Point2D.Double(location.getX(), location.getY());
		Point2D bottom = new Point2D.Double(location.getX(), location.getY() + size.getY() / 2);

		while (shape.contains(right)) {
			velocity.setLocation(velocity.getX() - 1, velocity.getY());
			right = new Point2D.Double(right.getX() + velocity.getX(), right.getY() + velocity.getY());
		}
		while (shape.contains(left))
		{
			velocity.setLocation(velocity.getX() + 1, velocity.getY());
			left = new Point2D.Double(left.getX() + velocity.getX(), left.getY() + velocity.getY());
		}
		while (shape.contains(top))
		{
			velocity.setLocation(velocity.getX(), velocity.getY() + 1);
			top = new Point2D.Double(top.getX() + velocity.getX(), top.getY() + velocity.getY());
		}
		while (shape.contains(bottom))
		{
			velocity.setLocation(velocity.getX(), velocity.getY() - 1);
			bottom = new Point2D.Double(bottom.getX() + velocity.getX(), bottom.getY() + velocity.getY());
		}

	}

	public void CheckSword() {
		// PUN
		Rectangle rect = new Rectangle((int) (location.getX() - 32), (int) (location.getY() - 32), 64,
				64);
		
		if (direction == Direction.UP) {
			rect.translate(0, -32);
		}
		else if (direction == Direction.DOWN) {
			rect.translate(0, 32);
		}
		else if (direction == Direction.LEFT) {
			rect.translate(-32, 0);
		}
		else if (direction == Direction.RIGHT) {
			rect.translate(32, 0);
		}
	
		swordDebug = rect;
		for (GameObject go : Project.gameObjects) {
			if (go.getCollision().intersects(rect)) {
				if (go instanceof Target)
					((Target) go).hit();
				if (go instanceof Enemy) {
					System.out.println("Attack Enemy");
					((Enemy) go).takeDamage(dame);
				}
			}
		}
	}

	public void takeDamage(int damage) {
		long currentTime = System.currentTimeMillis();
		if (isExisting()) {
			if (currentTime - lastAttackTime >= ATTACK_COOLDOWN) {
				lastAttackTime = currentTime;
				this.currentHealth -= damage;
//				System.out.println("Life: " + currentHealth);
			}
		}
	}

	public boolean isExisting() {
		if (currentHealth <= 0) {
			return false;
		}
		return true;
	}

	@Override
	public void draw(Graphics g) {
		int frameHeight = sprite.currentFrame.getHeight();
		int frameWidth = sprite.currentFrame.getWidth();
		// character debug bounds (oversized animations may appear beyond this box)
		g.setColor(Color.white);
		if (swordDebug != null) {
			((Graphics2D) g).drawRect(swordDebug.x - GamePanel.CameraX, swordDebug.y - GamePanel.CameraY, swordDebug.width, swordDebug.height);

		}
		g.drawImage(sprite.currentFrame, (int) (location.getX() - frameWidth / 2 - GamePanel.CameraX),
				(int) (location.getY() - frameHeight / 2 - GamePanel.CameraY), null); // (int) size.getX(), (int)
		((Graphics2D) g).drawRect((int) location.getX() - 15 - GamePanel.CameraX,
				(int) location.getY() - GamePanel.CameraY, 30, 30);
		g.setColor(Color.GREEN);
		g.fillRect((int) (location.getX()) - 20 - GamePanel.CameraX, (int) (location.getY()) - 40 - GamePanel.CameraY,
				currentHealth * 50 / health, 10); // HP
		g.drawRect((int) (location.getX()) - 20 - GamePanel.CameraX, (int) (location.getY()) - 40 - GamePanel.CameraY,
				50, 10); // HP

		// mana
		g.setColor(Color.BLUE);
		g.fillRect((int) (location.getX()) - 20 - GamePanel.CameraX, (int) (location.getY()) - 30 - GamePanel.CameraY,
				mana / 2, 5);
		g.drawRect((int) (location.getX()) - 20 - GamePanel.CameraX, (int) (location.getY()) - 30 - GamePanel.CameraY,
				50, 5);
//		Shape mine = this.getCollision();
//		Shape other = .getCollision();
//		Area myArea = new Area(mine);
//		Area otherArea = new Area(other);
//		myArea.intersect(otherArea);
//		
//		return !myArea.isEmpty();

		for (Block b : Map.blocks) {
			Shape mine = this.getCollision();
			Shape other = b.getCollision();
			Area myArea = new Area(mine);
			Area otherArea = new Area(other);
			myArea.intersect(otherArea);
			g.setColor(Color.pink);
			((Graphics2D) g).fill(myArea);
		}

		Graphics2D g2 = (Graphics2D) g;
		Point2D right = new Point2D.Double(location.getX() + size.getX() / 4, location.getY() + size.getY() / 4);
		Point2D left = new Point2D.Double(location.getX() - size.getX() / 4, location.getY() + size.getY() / 4);
		Point2D top = new Point2D.Double(location.getX(), location.getY());
		Point2D bottom = new Point2D.Double(location.getX(), location.getY() + size.getY() / 2);

		g2.setColor(Color.red);
		g2.fillRect((int) right.getX() - GamePanel.CameraX, (int) right.getY() - GamePanel.CameraY, 5, 5);

		g2.fillRect((int) left.getX() - GamePanel.CameraX, (int) left.getY() - GamePanel.CameraY, 5, 5);
		g2.setColor(Color.yellow);
		g2.fillRect((int) top.getX() - GamePanel.CameraX, (int) top.getY() - GamePanel.CameraY, 5, 5);
		g2.fillRect((int) bottom.getX() - GamePanel.CameraX, (int) bottom.getY() - GamePanel.CameraY, 5, 5);
	}

	@Override
	public void setupData() {
		this.fireballs = new ArrayList<>();
		this.sprite = new Sprite(Project.mainPath + "image/swordsman.png");
		Project.addActor(this);
//		Project.addGameObject(this);
	}
}