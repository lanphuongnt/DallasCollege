package ZeldaDownload;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.awt.image.RasterFormatException;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.imageio.ImageIO;


public abstract class Enemy extends GameObject implements Actor{
	
    public abstract void loadAnimation();

    private State state = State.IDLE;

//    Rectangle zone;
    int health;
    int currentHealth;
    int damage;
    private final String name;

    transient public BufferedImage[] walkingFrames = new BufferedImage[11];
    transient public BufferedImage[] flyingFrames =  new BufferedImage[4];
    transient public BufferedImage[] attackingFrames = new BufferedImage[11];
    transient public BufferedImage[] idleFrames = new BufferedImage[11];

    transient boolean isAttacking;

    public int animation = 0;
    float speed = 1.5f;
    transient Point2D movePosition;
    transient ArrayList<Point2D> movementNodes = new ArrayList<>();
	transient ArrayList<Point2D> movementPath = new ArrayList<>();

    private long lastAttackTime = 0;
    private static final long ATTACK_COOLDOWN = 100; // 1 second cooldown
//    private static final int ZONE_SIZE = 250;
    public Enemy(Point2D position, Point2D size, int health, int damage, String name) {
    	super(position, size);
        this.health = health;
        this.damage = damage;
        this.name = name;
        this.currentHealth = health;
        movementNodes.add(new Point2D.Double(position.getX(), position.getY()));
//        this.zone = new Rectangle(position.getX() - ZONE_SIZE/2)
        Project.addActor(this);
        Project.addGameObject(this);
        System.out.println("Enemy add to actor and gameob "  + Project.gameObjects.size() + " " + Project.actors.size());
    }

    public Enemy(int x, int y, int sizeX, int sizeY, int health, int damage, String name) {
    	this(new Point2D.Float(x, y), new Point2D.Float(sizeX, sizeY), health, damage, name);
    }

    public void setupData() {
    	idleFrames = new BufferedImage[11];
    	attackingFrames = new BufferedImage[11];
    	flyingFrames =  new BufferedImage[4];
    	walkingFrames = new BufferedImage[11];
    	movementNodes = new ArrayList<>();
    	movementPath = new ArrayList<>();
    	state = State.IDLE;
    	loadAnimation();
    	Project.addActor(this);
//        Project.addGameObject(this);
    }
    
    public void draw(Graphics g){
        if (!isExisting()){
            return;
        }
        BufferedImage[] actualFrame = switch (state) {
            case IDLE -> idleFrames;
            case WALKING -> walkingFrames;
            case ATTACKING -> attackingFrames;
        };
        
        
        Graphics2D g2 = (Graphics2D) g;
        g2.setColor(Color.white);
//        Rectangle2D cl = (Rectangle2D)getCollision();
        g2.drawRect((int)(location.getX() - size.getX()/3- GamePanel.CameraX), (int)(location.getY() - size.getY()/3- GamePanel.CameraY), (int) (size.getX() * 0.4f), (int)(size.getY() * 0.6f));
        g2.fillRect((int)location.getX() - GamePanel.CameraX, (int)location.getY() - GamePanel.CameraY, 3, 3);
        g2.drawImage(actualFrame[animation],(int) location.getX() - 50 - GamePanel.CameraX, (int)location.getY() - 40 - GamePanel.CameraY, (int)size.getX(), (int) size.getY(), null);
        animation =  (animation + 1) % actualFrame.length;
        
        
        g2.setColor(Color.RED);
//        System.out.println("HEALTH"+currentHealth);
        g2.fillRect((int) (location.getX())-30-GamePanel.CameraX, (int) (location.getY())+40 -GamePanel.CameraY, currentHealth*50/health, 10); //HP
        g2.drawRect((int) (location.getX())-30-GamePanel.CameraX, (int) (location.getY())+40-GamePanel.CameraY, 50, 10); //HP
        
        g2.setColor(Color.green);
        for (Point2D pt : movementNodes) {
        	g2.fillRect((int)pt.getX()- GamePanel.CameraX, (int)pt.getY()- GamePanel.CameraY, 10, 10);
        }
        g2.setColor(Color.red);
        for (Point2D pt : movementPath) {
        	g2.fillRect((int)pt.getX()- GamePanel.CameraX, (int)pt.getY()- GamePanel.CameraY, 10, 10);
        }
        g2.setColor(Color.yellow);
        if (movePosition != null) {
        	g2.fillRect((int)movePosition.getX()- GamePanel.CameraX, (int)movePosition.getY()- GamePanel.CameraY, 10, 10);
        	Line2D path = new Line2D.Float(new Point2D.Double(location.getX() -GamePanel.CameraX, location.getY() - GamePanel.CameraY), 
        			new Point2D.Double(movePosition.getX() -GamePanel.CameraX, movePosition.getY() - GamePanel.CameraY));
        	
        	// the shape of the path I am going (right now it is 1, we can widen it to fit
        	// the size of the character)
        	Shape line = new BasicStroke(5f).createStrokedShape(path);
        	g2.setColor(Color.pink);
        	g2.fill(line);
        	
        }
    }

    public Shape getCollision(){
    	return new Rectangle.Float((int)(location.getX() - size.getX()/3), (int)(location.getY() - size.getY()/3), (int) size.getX() * 0.4f, (int)size.getY() * 0.6f);
    }

    
    public void act(float time) {
    	this.detectPlayer(GamePanel.getCharacterLocation());
    	this.move(time);
    }
    public void move(float time) {
    	if (!movementPath.isEmpty() || movePosition != null) {
    		if (movePosition == null)
    			movePosition = movementPath.remove(0);
    		
    		double dx = movePosition.getX() - location.getX();
    	    double dy = movePosition.getY() - location.getY();
    	    
    	    double length = Math.sqrt(dx * dx + dy * dy);
    	    //add code
    	    if (length == 0)
    	    {
    	    	attack();
    	    }
    	    if (length == 0)
    	    {	    	
    	    	movePosition = null;
    	    	return;
    	    }
    	    else if (length < speed)
    	    {
    	    	location.setLocation(movePosition);
    	    	return;
    	    }
            double nx = dx / length;
    	    double ny = dy / length;
    	    
    	    //move the actual location
    	    location.setLocation(location.getX()+nx * speed, location.getY() + ny * speed);

//    	    location.x += (int)(nx*speed);
//    	    location.y += (int)(ny*speed);
    	}
    }

    public void detectPlayer(Point2D playerLocation) {
    	GameObject g = GameObject.trace(location, playerLocation, Arrays.asList(this));
		if (g != null)
		{
			for (Point2D p : movementNodes)
			{
				boolean reachP = GameObject.trace(location, p, Arrays.asList(this)) == null;
				boolean PreachGoal = GameObject.trace(playerLocation, p, Arrays.asList(this)) == null;
				if (reachP && PreachGoal)
				{
					movementPath.clear();
					movementPath.add(p);
					movementPath.add(playerLocation);
					return;
				}
			}
		}
		else {
			movementPath.clear();
			movementPath.add(playerLocation);
			movePosition = null;
		}
    }  

    public void attacking(){
        isAttacking = true;
        state = State.ATTACKING;
        attack();
    }

    public void attack() {
    	Rectangle rect = new Rectangle((int) (location.getX() - 32), (int) (location.getY() - 32), 64,64);
    	for (Actor a: Project.actors)
    	{
    		if (a instanceof Character) {
                if (isExisting()){
                    if (((Character) a).getCollision().intersects(rect))
                        ((Character) a).takeDamage(damage);;
                }else{
                    return;
                }
    		}
    	}
    }
	
    public void takeDamage(int damage) {
        long currentTime = System.currentTimeMillis();
        if (isExisting()) {
            if (currentTime - lastAttackTime >= ATTACK_COOLDOWN) {
                lastAttackTime = currentTime;
            	this.currentHealth -=damage;
                System.out.println(name + " takes " + damage + " damage! Remaining health: " + currentHealth);
                System.out.println("------");
            }
        }
    }

    public boolean isExisting() {
        if (currentHealth <= 0) {
            return false;
        }else{
            return true;
        }
    }

}

class NormalEnemy extends Enemy{

    public NormalEnemy(Point2D location, int health, int damage, String name) {
        super(location, new Point2D.Float(80, 80), health, damage, name);
        loadAnimation();
    }
    public NormalEnemy(int x, int y, int health, int damage, String name) {
    	this(new Point2D.Float(x, y), health, damage, name);
    }

    @Override
    public void loadAnimation(){

        String path = Project.mainPath + "image/Enemy/Wraith_01/PNG_Sequences/"; // change to your path
        for (int i = 0; i < walkingFrames.length; i++) {
            try{
                walkingFrames[i] = ImageIO.read(new File( path + "Walking/Wraith_01_Moving_Forward_00" + i + ".png"));
                attackingFrames[i] = ImageIO.read(new File(path + "Attacking/Wraith_01_Attack_00" + i + ".png"));
                idleFrames[i] = ImageIO.read(new File(path + "/Idle_Blink/Wraith_01_Idle_Blinking_00" + i + ".png"));
            }catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}

class Boss extends Enemy{

    int frame = 0;

    public Boss(Point2D location, int health, int damage, String name) {
        super(location, new Point2D.Float(50, 50),health, damage, name);
        loadAnimation();
    }

    public Boss(int x, int y, int health, int damage, String name) {
    	this(new Point2D.Float(x, y), health, damage, name);
    }

    @Override
    public void draw(Graphics g){
        Graphics2D g2 = (Graphics2D) g;
        if (!isExisting()) return;
        g.drawImage(flyingFrames[frame], (int) location.getX() - 70, (int) location.getY() - 50, 90, 90, null);
        frame = (frame + 1) % flyingFrames.length;
    }

    @Override
    public void loadAnimation(){
        final int frameWidth = 81;
        final int frameHeight = 71;
        int totalFrames = 4;

        flyingFrames = new BufferedImage[totalFrames];

        try {
            BufferedImage bossSheet = ImageIO.read(new File(Project.mainPath + "image/Enemy/Boss/Flying.png"));

            for (int i = 0; i < totalFrames; i++) {
                flyingFrames[i] = bossSheet.getSubimage(i * frameWidth, 0, frameWidth, frameHeight);
            }

        } catch (IOException | RasterFormatException e) {
            e.printStackTrace();
        }
    }
}