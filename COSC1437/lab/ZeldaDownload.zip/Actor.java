package ZeldaDownload;

import java.awt.Shape;

public interface Actor {
	void act(float time);

}
