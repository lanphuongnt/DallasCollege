// COSC - 1436 - 81812
// Dallas College
// Bonus Assignment
// Student 1: Phuong Nguyen - 3817096
// Student 2: Trung Nguyen - 3814326


#include <iostream>
#include <fstream>
#include <string>
#include <Windows.h>
#include <array>
#include <vector>
#include <random>
#include <time.h>

//get the output window
const HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);


using namespace std;

const int BOARD_SIZE = 20;
const int WHITE = 7;
const int BLUE = 9;
const int GREEN = 10;
const int OBSTACLE_SIZE = 5;
const int TOTAL_OBSTACLE = 15;


void ShowConsoleCursor(bool showFlag)
{
	CONSOLE_CURSOR_INFO     cursorInfo;
	GetConsoleCursorInfo(hConsole, &cursorInfo);
	cursorInfo.bVisible = showFlag; // set the cursor visibility
	SetConsoleCursorInfo(hConsole, &cursorInfo);
}

int randomColor() {
	return rand() % 15 + 1;
}


void createObstacleInLine(bool map[][BOARD_SIZE], int direction[], int color[], int &totalObstacle, int sizeOfObstacle = OBSTACLE_SIZE, int line = 0) {
	int startingPosition = rand() % (BOARD_SIZE - sizeOfObstacle + 1); // 
	for (int i = 0; i < sizeOfObstacle; i++) {
		map[line][startingPosition + i] = true;
	}
	if (map[line][0]) {
		direction[line] = 1;
	}
	else if (map[line][BOARD_SIZE - 1]) {
		direction[line] = -1;
	}
	else {
		direction[line] = (rand() % 2 ? -1 : 1);
	}
	color[line] = 16 * randomColor();
	totalObstacle++;
}

void drawBoarderOfGame() {
	for (int i = 0; i < BOARD_SIZE; i++) {
		for (int j = 0; j < BOARD_SIZE; j++) {
			cout << " ";
		}
		cout << "|" << endl;
	}
	for (int i = 0; i < BOARD_SIZE; i++) {
		cout << "_";
	}
	cout << "|" << endl;
	COORD firstPosition = { 0, 0 };
	SetConsoleCursorPosition(hConsole, firstPosition);
}

void printMap(bool map[][BOARD_SIZE], int color[BOARD_SIZE]) {
	COORD firstPosition = { 0, 0 };
	SetConsoleCursorPosition(hConsole, firstPosition);
	for (int i = 0; i < BOARD_SIZE; i++) {
		for (int j = 0; j < BOARD_SIZE; j++) {
			if (map[i][j]) {
				SetConsoleTextAttribute(hConsole, color[i]);
				cout << " ";
				SetConsoleTextAttribute(hConsole, 7);
			}
			else {
				cout << " ";
			}
		}
		cout << endl;
	}
}

void resetMap(bool map[][BOARD_SIZE]) {
	for (int i = 0; i < BOARD_SIZE; i++) {
		for (int j = 0; j < BOARD_SIZE; j++) {
			map[i][j] = false;
		}
	}
}

void createRandomMap(bool map[][BOARD_SIZE], int direction[], int color[], int &totalObstacle) {
	resetMap(map);
	for (int i = 0; i < BOARD_SIZE; i+=2) {
		createObstacleInLine(map, direction, color, totalObstacle, OBSTACLE_SIZE, i);
	}
}

void moveObstacleInHorizontal(bool map[][BOARD_SIZE], int direction[]) {
	for (int i = 0; i < BOARD_SIZE; i++) {
		if (!direction[i]) {
			continue;
		}
		// Find the starting position of obstacle
		int j = 0;
		while (map[i][j] == false && j < BOARD_SIZE) {
			j++;
		}
		// move obstacle if find out obstacle in line i
		if (j < BOARD_SIZE) {
			if (j == 0 || j + OBSTACLE_SIZE == BOARD_SIZE) {
				direction[i] *= -1; // reverse direction
			}
			if (direction[i] == 1 && j + OBSTACLE_SIZE < BOARD_SIZE) {
				map[i][j] = false;
				map[i][j + OBSTACLE_SIZE] = true;
			}
			else if (direction[i] == -1 && j > 0) {
				map[i][j - 1] = true;
				map[i][j + OBSTACLE_SIZE - 1] = false;
			}
		}
	}
}

void moveMapDown(bool map[][BOARD_SIZE], int direction[], int color[], int &totalObstacle) {
	// move map down
	for (int i = BOARD_SIZE; i > 0; i--) {
		for (int j = 0; j < BOARD_SIZE; j++) {
			map[i][j] = map[i - 1][j];
			direction[i] = direction[i - 1];
			color[i] = color[i - 1];
		}
	}
	// remove the first line
	for (int j = 0; j < BOARD_SIZE; j++) {
		map[0][j] = false;
	}
	direction[0] = color[0] = 0;
	if (direction[0] == 0 && direction[1] == 0) {
		createObstacleInLine(map, direction, color, totalObstacle, OBSTACLE_SIZE, 0);
	}
}


bool hitTheObstacle(bool map[][BOARD_SIZE], COORD pos) {
	if (pos.X < 0 || pos.X >= BOARD_SIZE) return false;
	if (pos.Y < 0 || pos.Y >= BOARD_SIZE) return false;
	return map[pos.Y][pos.X];
}

int getOption(string listOptions[], int sizeOption, COORD pos)
{
	unsigned int selection = 0;
	//set this to true when the screen should be updated
	bool dirty = true;
	while (true)
	{
		if (dirty) //update the options screen
		{
			SetConsoleTextAttribute(hConsole, 0xE);
			//system("cls");

			SetConsoleCursorPosition(hConsole, pos);

			for (int i = 0; i < sizeOption; i++) {

				if (selection == i)
					SetConsoleTextAttribute(hConsole, 16 * BLUE + 0xE); //highlight color
				else
					SetConsoleTextAttribute(hConsole, 6);
				cout << listOptions[i] << endl;
				pos.Y++;
				SetConsoleCursorPosition(hConsole, pos);
			}
			pos.Y -= sizeOption;

			dirty = false;
		}
		Sleep(50);

		SetConsoleTextAttribute(hConsole, 7);

		//Virtual Key Codes: https://msdn.microsoft.com/en-us/library/windows/desktop/dd375731(v=vs.85).aspx
		if (GetAsyncKeyState(0x26) && selection > 0)//UP
		{
			selection--;
			dirty = true;
		}
		else if (GetAsyncKeyState(0x28) && selection + 1 < sizeOption) //DOWN
		{
			selection++;
			dirty = true;
		}
		else if (GetAsyncKeyState(0x0D)) //Enter
		{
			system("cls");
			drawBoarderOfGame();
			return selection;
		}
	}
}




int menu(const COORD& pos) {
	string listOptions[4] = { "START", "LEVEL", "INFOR", "QUIT"};
	return getOption(listOptions, 4, pos);
}

int levelMenu(const COORD& pos) {
	string listOptions[3] = { " SLOW ", "MEDIUM", " FAST " };
	return getOption(listOptions, 3, pos);
}

int endGameMenu(const COORD& pos) {
	string listOptions[2] = { "REPLAY", " HOME " };
	return getOption(listOptions, 2, pos);
}

int pauseGameMenu(const COORD& pos) {
	string listOptions[] = { "CONTINUE", " REPLAY ", "  HOME  ", "  QUIT  " };
	return getOption(listOptions, 4, pos);
}

int inforMenu(const COORD &pos) {
	string listOptions[1] = { "[ QUIT ]" };
	return getOption(listOptions, 1, pos);
}

void homePage() {
	COORD pos;
	pos.X = 2;
	pos.Y = 1;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "****************" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*  (\\_/)       *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*  ( �_�)      *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*  / > <333333 *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*    PN&TN     *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "****************" << endl;
}

void inforPage() {
	COORD pos;
	pos.X = 2;
	pos.Y = 1;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*****************" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*   COSC-1436   *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*               *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*     Author    *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "* Phuong Nguyen *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*       &       *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "* Trung  Nguyen *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*  (\\_/)       *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*  ( �_�)      *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*  / > <333333 *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*     PAUSE    *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*  [ PRESS P ] *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "****************" << endl;

	pos = { 6, 18 };
	inforMenu(pos);
}

void loseNotification() {
	COORD pos;
	pos.X = 2;
	pos.Y = 5;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "****************" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*   YOU LOSE!  *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*  (\\_/)       *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*  ( �_�)      *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*  / > <33333  *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "****************" << endl;
}

void winNotification() {
	COORD pos;
	pos.X = 2;
	pos.Y = 5;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "****************" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*   You win!   *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*  (\\_/)       *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*  ( �_�)      *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*  / > <33333  *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "****************" << endl;
}

void quitPage() {
	system("cls");
	drawBoarderOfGame();
	
	COORD pos;
	pos.X = 2;
	pos.Y = 1;
	
	SetConsoleCursorPosition(hConsole, pos);
	cout << "****************" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*     BYE      *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*  Quit in...  *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*    [ X ]     *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*  (\\_/)       *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*  ( �_�)      *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*  / > <333333 *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*    PN&TN     *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "*              *" << endl;
	pos.Y++;
	SetConsoleCursorPosition(hConsole, pos);
	cout << "****************" << endl;

	pos = { 9, 6 };
	for (int i = 3; i > 0; i--) {
		SetConsoleCursorPosition(hConsole, pos);
		cout << i;
		Sleep(1000);
	}
}


int main()
{
	srand(time(NULL));
	ShowConsoleCursor(false);
	
	bool quit, home, endGame;
	quit = endGame = false;
	home = true;
	while (true) {
		// Menu
		system("cls");
		drawBoarderOfGame();
		COORD menuPosition = { 7, 5 };
		int level = 0;
		if (home) {
			int option = -1;
			while (option) {
				homePage();
				option = menu(menuPosition);
				Sleep(300); // wait enter key released

				if (option == 1) {
					homePage();
					level = levelMenu(menuPosition);
					Sleep(300);
				}
				else if (option == 2) {
					inforPage();
					Sleep(300);
				}
				else if (option == 3) {
					quit = true;
					break;
				}
			}
			home = false;
		}

		if (quit) {
			quitPage();
			system("cls");
			break;
		}

		bool map[BOARD_SIZE + 1][BOARD_SIZE];
		// direction[i] = 0 if line i doesnt have any obstacle
		// direction[i] = 1 if obstacle in line i moves to the right
		// direction[i] = -1 if obstacle in line i moves to the left
		int direction[BOARD_SIZE + 1];
		int color[BOARD_SIZE + 1];
		int totalObstacle = 0;
		for (int i = 0; i < BOARD_SIZE; i++) {
			direction[i] = color[i] = 0;
		}

		createRandomMap(map, direction, color, totalObstacle);

		SetConsoleTextAttribute(hConsole, 15);
		COORD pos;
		pos.X = 10;
		pos.Y = 19;
		bool update = true;
		quit = home = endGame = false;
		while (true)
		{	
			// End game notification
			if (endGame) {
				menuPosition = { 7, 8 };
				int option = endGameMenu(menuPosition);
				if (option == 0) {
					home = false;
				}
				else if (option == 1) {
					home = true;
				}
				break;
			}
			

			if (GetAsyncKeyState(0x50) & 0x8000) {// character 'P' is being pressed
				int optionPause = pauseGameMenu(menuPosition);
				if (optionPause == 1) {
					home = false;
					break;
				}
				else if (optionPause == 2) {
					home = true;
					break;
				}
				else if (optionPause == 3) {
					quit = true;
					break;
				}
			}

			{
				system("cls");
				drawBoarderOfGame();

				moveObstacleInHorizontal(map, direction);
				printMap(map, color);
				SetConsoleCursorPosition(hConsole, pos);
				cout << "@";
				update = false;
			}

			if (pos.Y == 0 && totalObstacle == TOTAL_OBSTACLE) {
				winNotification();
				endGame = true;
				continue;
			}


			if (pos.Y < BOARD_SIZE - 4 && !direction[pos.Y] && totalObstacle != TOTAL_OBSTACLE) {
				pos.Y++;
				moveMapDown(map, direction, color, totalObstacle);
				Sleep(40);
			}

			if (GetAsyncKeyState(0x25) && pos.X > 0) //left
			{
				pos.X -= 1;
				update = true;
			}
			else if (GetAsyncKeyState(0x27) && pos.X < BOARD_SIZE - 1)//right
			{
				pos.X += 1;
				update = true;
			}
			if (GetAsyncKeyState(0x26) && pos.Y > 0) //up
			{
				pos.Y--;
				update = true;
			}
			else if (GetAsyncKeyState(0x28) && pos.Y < BOARD_SIZE - 1)//down
			{
				pos.Y++;
				update = true;
			}
			
			if (hitTheObstacle(map, pos)) {
				loseNotification();
				endGame = true;
				continue;
			}

			// Speed of Obstacle
			Sleep(100 - 30 * level);
		}
	}
	

	return 0;
}